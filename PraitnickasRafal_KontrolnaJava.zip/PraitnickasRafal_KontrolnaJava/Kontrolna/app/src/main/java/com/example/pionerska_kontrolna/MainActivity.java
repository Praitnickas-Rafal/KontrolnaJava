package com.example.pionerska_kontrolna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MainActivity extends AppCompatActivity {

    private EditText inputEditText;
    private EditText outputEditText;
    private LinearLayout resultListLayout;
    private Button calculateButton;

    private int resultCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        outputEditText = findViewById(R.id.output_edit_text);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputEditText = findViewById(R.id.input_edit_text);
        outputEditText = findViewById(R.id.output_edit_text);
        resultListLayout = findViewById(R.id.result_list_layout);
        calculateButton = findViewById(R.id.calculate_button);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });
    }

    private void calculateResult() {
        String inputText = inputEditText.getText().toString();
        if (inputText.matches("\\d+")) {
            calculateButton.setEnabled(true);
            int inputValue = Integer.parseInt(inputText);
            double result = Math.sqrt(inputValue);

            String resultString = String.format("%d. %d = %.2f\n", ++resultCounter, inputValue, result);

            outputEditText.append(resultString);

            if (resultCounter > 5) {
                outputEditText.setText("");
                resultCounter = 0;
            }

            ScrollView scrollView = findViewById(R.id.result_list_scroll_view);
            scrollView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    scrollView.fullScroll(View.FOCUS_DOWN);
                }
            }, 100);
        } else {
            calculateButton.setEnabled(false);
            inputEditText.setError("Proszę wpisać liczbę Dodatnią!");
        }
    }
}